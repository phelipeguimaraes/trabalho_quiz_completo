package codigos;

public class cabecalho {
    public String faculdade = "";
    public String nome = "";
    public String materia = "";
    public String professor = "";

    public void escrevaCabecalho() {
        System.out.println(this.faculdade);
        System.out.println(this.nome);
        System.out.println(this.materia);
        System.out.println(this.professor);
    }

}
